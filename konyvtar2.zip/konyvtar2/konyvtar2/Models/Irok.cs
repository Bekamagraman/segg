﻿using System;
using System.Collections.Generic;

namespace konyvtar2.Models;

public partial class Irok
{
    public int Iroid { get; set; }

    public string IroNeve { get; set; } = null!;

    public int? SzuletesiEv { get; set; }

    public string? Nemzetiseg { get; set; }

    public virtual ICollection<Konyvek> Konyveks { get; set; } = new List<Konyvek>();
}
