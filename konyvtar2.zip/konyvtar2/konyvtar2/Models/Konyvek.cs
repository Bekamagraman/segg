﻿using System;
using System.Collections.Generic;

namespace konyvtar2.Models;

public partial class Konyvek
{
    public int Id { get; set; }

    public string KonyvCime { get; set; } = null!;

    public int? KiadasEve { get; set; }

    public int? Iroid { get; set; }

    public int? Konyvtipusid { get; set; }

    public string? Nehezseg { get; set; }

    public virtual Irok? Iro { get; set; }

    public virtual Konyvtipusok? Konyvtipus { get; set; }
}
