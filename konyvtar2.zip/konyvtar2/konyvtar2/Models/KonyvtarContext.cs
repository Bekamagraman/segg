﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace konyvtar2.Models;

public partial class KonyvtarContext : DbContext
{
    public KonyvtarContext()
    {
    }

    public KonyvtarContext(DbContextOptions<KonyvtarContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Irok> Iroks { get; set; }

    public virtual DbSet<Konyvek> Konyveks { get; set; }

    public virtual DbSet<Konyvtipusok> Konyvtipusoks { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=konyvtar;Integrated Security=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Irok>(entity =>
        {
            entity.HasKey(e => e.Iroid).HasName("PK__irok__36C68FAEB0B7298E");

            entity.ToTable("irok");

            entity.Property(e => e.Iroid).HasColumnName("iroid");
            entity.Property(e => e.IroNeve)
                .HasMaxLength(100)
                .HasColumnName("iro_neve");
            entity.Property(e => e.Nemzetiseg)
                .HasMaxLength(50)
                .HasColumnName("nemzetiseg");
            entity.Property(e => e.SzuletesiEv).HasColumnName("szuletesi_ev");
        });

        modelBuilder.Entity<Konyvek>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__konyvek__3213E83FE505A5DD");

            entity.ToTable("konyvek");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Iroid).HasColumnName("iroid");
            entity.Property(e => e.KiadasEve).HasColumnName("kiadas_eve");
            entity.Property(e => e.KonyvCime)
                .HasMaxLength(200)
                .HasColumnName("konyv_cime");
            entity.Property(e => e.Konyvtipusid).HasColumnName("konyvtipusid");
            entity.Property(e => e.Nehezseg)
                .HasMaxLength(10)
                .HasColumnName("nehezseg");

            entity.HasOne(d => d.Iro).WithMany(p => p.Konyveks)
                .HasForeignKey(d => d.Iroid)
                .HasConstraintName("fk_iro");

            entity.HasOne(d => d.Konyvtipus).WithMany(p => p.Konyveks)
                .HasForeignKey(d => d.Konyvtipusid)
                .HasConstraintName("fk_tipus");
        });

        modelBuilder.Entity<Konyvtipusok>(entity =>
        {
            entity.HasKey(e => e.Konyvtipusid).HasName("PK__konyvtip__9A49B1877A1DCC1A");

            entity.ToTable("konyvtipusok");

            entity.Property(e => e.Konyvtipusid).HasColumnName("konyvtipusid");
            entity.Property(e => e.Altipus)
                .HasMaxLength(50)
                .HasColumnName("altipus");
            entity.Property(e => e.KonyvTipusa)
                .HasMaxLength(50)
                .HasColumnName("konyv_tipusa");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
