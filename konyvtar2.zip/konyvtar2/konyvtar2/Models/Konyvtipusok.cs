﻿using System;
using System.Collections.Generic;

namespace konyvtar2.Models;

public partial class Konyvtipusok
{
    public int Konyvtipusid { get; set; }

    public string KonyvTipusa { get; set; } = null!;

    public string? Altipus { get; set; }

    public virtual ICollection<Konyvek> Konyveks { get; set; } = new List<Konyvek>();
}
