﻿using konyvtar2.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace konyvtar2
{
    public partial class MainWindow : Window
    {
        KonyvtarContext cn;

        public MainWindow()
        {
            InitializeComponent();
            gHozzaad.Visibility = Visibility.Hidden;
            cn = new KonyvtarContext();

            Betolt();
        }

        // Könyvek betöltése
        private void Betolt()
        {
            var konyvLista = cn.Konyveks
                               .Include(k => k.Iro)
                               .ToList();

            BooksControl.ItemsSource = konyvLista;
        }

        // Főoldal
        private void fooldal(object sender, RoutedEventArgs e)
        {
            gHozzaad.Visibility = Visibility.Hidden;
            gBal.Visibility = Visibility.Visible;
           
        }

        // Könyv hozzáadás oldal
        private void hozzaad(object sender, RoutedEventArgs e)
        {
            gBal.Visibility = Visibility.Hidden;
            gHozzaad.Visibility = Visibility.Visible;
        }

        // Beállítások
        private void beal(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ez itt a Beállítások");
            
        }

        // Kilépés
        private void kilep(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        // Keresés gomb
        private void keres_click(object sender, RoutedEventArgs e)
        {
            string keres = tbSearch.Text.ToLower();

            var lista = cn.Konyveks
                          .Include(k => k.Iro)
                          .Where(k => k.KonyvCime.ToLower().Contains(keres))
                          .ToList();

            BooksControl.ItemsSource = lista;
        }

        // Élő keresés
        private void keres(object sender, TextChangedEventArgs e)
        {
            keres_click(sender, e);
        }

        // Könyv hozzáadás
        private void konyv_add(object sender, RoutedEventArgs e)
        {
            if (tbTitle.Text.Length == 0)
            {
                MessageBox.Show("Add meg a könyv címét!");
                return;
            }

            bool joEv = int.TryParse(tbYear.Text, out int ev);

            if (!joEv)
            {
                MessageBox.Show("Hibás évszám!");
                return;
            }

            Konyvek uj = new Konyvek();

            uj.KonyvCime = tbTitle.Text;
            uj.KiadasEve = ev;
            uj.Nehezseg = tbDifficulty.Text;

            cn.Konyveks.Add(uj);

            cn.SaveChanges();

            MessageBox.Show("Könyv hozzáadva!");

            Betolt();
        }

        // Kijelölt könyv adatainak betöltése textboxba
        private void konyv_lista(object sender, SelectionChangedEventArgs e)
        {
            if (BooksControl.SelectedItem is Konyvek k)
            {
                tbTitle.Text = k.KonyvCime;
                tbYear.Text = k.KiadasEve.ToString();
                tbDifficulty.Text = k.Nehezseg;
            }
        }

        // Könyv módosítás
        private void konyv_mod(object sender, RoutedEventArgs e)
        {
            if (BooksControl.SelectedItem is not Konyvek k)
            {
                MessageBox.Show("Nincs kiválasztott könyv!");
                return;
            }

            if (tbTitle.Text.Length == 0)
            {
                MessageBox.Show("Adj meg címet!");
                return;
            }

            bool joEv = int.TryParse(tbYear.Text, out int ev);

            if (!joEv)
            {
                MessageBox.Show("Hibás évszám!");
                return;
            }

            k.KonyvCime = tbTitle.Text;
            k.KiadasEve = ev;
            k.Nehezseg = tbDifficulty.Text;

            cn.SaveChanges();

            MessageBox.Show("Módosítva!");

            Betolt();
        }

        // Könyv törlése
        private void konyv_torol(object sender, RoutedEventArgs e)
        {
            if (BooksControl.SelectedItem is not Konyvek k)
            {
                MessageBox.Show("Nincs kiválasztott könyv!");
                return;
            }

            cn.Konyveks.Remove(k);

            cn.SaveChanges();

            MessageBox.Show("Törölve!");

            Betolt();
        }


    }
}