﻿using konyvtar2.Models;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore;
namespace konyvtar2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Betolt();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            gBal.Visibility = Visibility.Visible;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            gBal.Visibility = Visibility.Collapsed;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            gBal.Visibility = Visibility.Collapsed;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void Betolt()
        {
            using (var db = new KonyvtarContext())
            {
                // Lekérjük a könyveket, és hozzácsapjuk az írókat is (Eager Loading)
                var konyvLista = db.Konyveks
                                   .Include(k => k.Iro)
                                   .ToList();

                // Beállítjuk a forrást a listának
                BooksControl.ItemsSource = konyvLista;
            }
        }
    }
}